import org.junit.jupiter.api.Test;

public class Method1Test {
    @Test
    void test1()
    {
        System.out.println("Test Class Method 1");
    }
    @Test
    void test2()
    {
        System.out.println("Test Class Method 2");
    }
}
